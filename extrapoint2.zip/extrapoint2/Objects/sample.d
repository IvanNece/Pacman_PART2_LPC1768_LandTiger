./objects/sample.o: Source\sample.c \
  C:\Users\Ivan\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\LPC17xx.h \
  Source\CMSIS_core\core_cm3.h \
  C:\Users\Ivan\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\system_LPC17xx.h \
  Source\GLCD\GLCD.h Source\GLCD\HzLib.h Source\TouchPanel\TouchPanel.h \
  Source\timer\timer.h Source\RIT\RIT.h Source\button_EXINT\button.h \
  Source\joystick\joystick.h Source\led\led.h \
  Source\labyrinth\labyrinth.h Source\Pacman\Pacman.h \
  Source\Ghost\Ghost.h Source\music\music.h

./objects/funct_joystick.o: Source\joystick\funct_joystick.c \
  C:\Users\Ivan\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\LPC17xx.h \
  Source\CMSIS_core\core_cm3.h \
  C:\Users\Ivan\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\system_LPC17xx.h \
  Source\joystick\joystick.h Source\joystick\..\led\led.h \
  Source\Pacman\Pacman.h Source\GLCD\GLCD.h Source\Ghost\Ghost.h \
  Source\labyrinth\labyrinth.h

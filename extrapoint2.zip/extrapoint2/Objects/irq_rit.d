./objects/irq_rit.o: Source\RIT\IRQ_RIT.c \
  C:\Users\Ivan\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\LPC17xx.h \
  Source\CMSIS_core\core_cm3.h \
  C:\Users\Ivan\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.2\Device\Include\system_LPC17xx.h \
  Source\RIT\RIT.h Source\RIT\..\led\led.h Source\RIT\..\timer\timer.h \
  Source\RIT\..\GLCD\GLCD.h Source\joystick\joystick.h \
  Source\Pacman\Pacman.h Source\GLCD\GLCD.h Source\Ghost\Ghost.h \
  Source\labyrinth\labyrinth.h Source\music\music.h Source\CAN\CAN.h \
  Source\CAN\..\TouchPanel\TouchPanel.h
